const $=id=>document.getElementById(id);
let generated=[];
const openTab=name=>{document.querySelectorAll('.pane').forEach(x=>x.classList.toggle('hidden',x.id!==name));document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.tab===name));if(name==='biblioteca')renderLibrary()};
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>openTab(b.dataset.tab)));
$('photo').addEventListener('change',e=>{const f=e.target.files[0];if(!f)return;const img=$('preview');img.src=URL.createObjectURL(f);img.classList.remove('hidden')});
const hooks=[
["Gancho directo","Si estás buscando una forma práctica de aprovechar [PRODUCTO], mira esto."],
["Problema y solución","A veces resolver algo cotidiano no tiene por qué ser complicado. Por eso hoy te quiero mostrar [PRODUCTO]."],
["Curiosidad","Hay productos que llaman la atención por lo sencillo que puede ser su uso. Este es [PRODUCTO]."],
["Demostración","Te enseño de cerca [PRODUCTO] y las características que vale la pena conocer."],
["Experiencia conversacional","Mira lo que tenemos por aquí: [PRODUCTO]. Te cuento rápidamente qué ofrece."],
["Lista de beneficios","Tres cosas que puedes revisar de [PRODUCTO]: sus características, su utilidad y si encaja con lo que necesitas."],
["Para quién es","Si este tipo de producto te hace falta, quizá quieras conocer [PRODUCTO] y lo que ofrece."],
["Enfoque práctico","Vamos directo al punto: esto es [PRODUCTO] y estas son sus características principales."],
["Objeción y respuesta","Antes de elegir un producto, conviene saber qué incluye y qué puede ofrecer. Vamos a revisar [PRODUCTO]."],
["Cierre cercano","Si te interesa [PRODUCTO], revisa sus detalles y decide si es justo lo que estabas buscando."]
];
const endings=["Échale un vistazo en el enlace del producto y revisa los detalles antes de comprar.","Si te interesa, consulta la publicación para ver disponibilidad y más información.","Te dejo el producto para que puedas conocerlo mejor y decidir por ti mismo."];
function makeScript(name,details,duration,style,i){
 const [angle,hook]=hooks[i];let intro=hook.replaceAll('[PRODUCTO]',name);
 let body=details?` Entre lo que debes conocer está lo siguiente: ${details}.`:` Revisa sus características y confirma que se adapte a lo que necesitas.`;
 let styleLine=style==='Natural'?" Te lo cuento sin complicaciones, para que tengas la información a la mano.":style==='Demostrativo'?" Lo importante es mostrar cómo es y explicar cada característica con claridad.":style==='Persuasivo'?" Puede ser una opción interesante si sus características coinciden con lo que buscas.":style==='Problema y solución'?" La clave es identificar si realmente resuelve una necesidad que tienes.":" Lo mejor es conocerlo y valorar si encaja contigo.";
 let close=endings[i%endings.length];
 return `${intro}${body}${styleLine} ${close}`;
}
$('generate').addEventListener('click',()=>{
 const name=$('product').value.trim(),details=$('details').value.trim();
 if(!name){alert('Escribe el nombre del producto.');return}
 if(!details){alert('Añade al menos una característica confirmada para evitar inventar información.');return}
 const duration=$('duration').value,style=$('style').value;
 generated=hooks.map((h,i)=>({id:Date.now()+i,product:name,title:`${i+1}. ${h[0]}`,duration,text:makeScript(name,details,duration,style,i)}));
 const out=$('results');out.innerHTML='<h3>Diez propuestas · '+escapeHtml(name)+'</h3>';
 generated.forEach((s,i)=>{const el=document.createElement('article');el.className='script';el.innerHTML=`<h3>${escapeHtml(s.title)} <span class="pill">${escapeHtml(duration)}</span></h3><p>${escapeHtml(s.text)}</p><div class="script-actions"><button class="btn secondary" data-copy="${i}">Copiar</button><button class="btn secondary" data-save="${i}">Guardar</button></div>`;out.appendChild(el)});
 out.querySelectorAll('[data-copy]').forEach(b=>b.onclick=()=>copy(generated[+b.dataset.copy].text));
 out.querySelectorAll('[data-save]').forEach(b=>b.onclick=()=>save(generated[+b.dataset.save]));
});
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function copy(s){if(navigator.clipboard?.writeText)navigator.clipboard.writeText(s).then(()=>alert('Copiado.')).catch(()=>fallbackCopy(s));else fallbackCopy(s)}
function fallbackCopy(s){const t=document.createElement('textarea');t.value=s;document.body.appendChild(t);t.select();document.execCommand('copy');t.remove();alert('Copiado.')}
function getSaved(){try{return JSON.parse(localStorage.getItem('thanator-library')||'[]')}catch{return []}}
function save(item){const arr=getSaved();if(arr.some(x=>x.text===item.text)){alert('Ese guion ya está guardado.');return}arr.unshift(item);localStorage.setItem('thanator-library',JSON.stringify(arr));alert('Guion guardado en tu biblioteca.')}
function renderLibrary(){const arr=getSaved(),el=$('library');if(!arr.length){el.innerHTML='<div class="empty">Todavía no has guardado guiones.</div>';return}el.innerHTML='';arr.forEach((s,i)=>{const card=document.createElement('article');card.className='script';card.innerHTML=`<h3>${escapeHtml(s.product)} · ${escapeHtml(s.title)}</h3><p>${escapeHtml(s.text)}</p><div class="script-actions"><button class="btn secondary" data-copy="${i}">Copiar</button><button class="btn danger" data-del="${i}">Eliminar</button></div>`;el.appendChild(card)});el.querySelectorAll('[data-copy]').forEach(b=>b.onclick=()=>copy(arr[+b.dataset.copy].text));el.querySelectorAll('[data-del]').forEach(b=>b.onclick=()=>{const a=getSaved();a.splice(+b.dataset.del,1);localStorage.setItem('thanator-library',JSON.stringify(a));renderLibrary()})}
$('makePost').onclick=()=>{const n=$('pubProduct').value.trim(),d=$('pubDetails').value.trim();if(!n){alert('Escribe el producto.');return}const titles=[`¿Ya conocías ${n}?`,`Te muestro ${n}: conoce sus detalles`,`¿Vale la pena ${n}? Esto debes revisar`,`Una opción que quizá quieras conocer: ${n}`,`Conoce mejor ${n} antes de decidir`];const tags=['#TikTokShop','#Recomendaciones','#LoQuiero','#ProductosUtiles','#TikTokMeHizoComprar'];$('postResults').innerHTML=`<h3>Ideas para tu publicación</h3><div class="script"><p>${titles.map((x,i)=>(i+1)+'. '+x).join('\\n')}</p><p>${tags.join(' ')}</p><p>${escapeHtml(d)}</p><button class="btn secondary" id="copyPost">Copiar ideas</button></div>`;$('copyPost').onclick=()=>copy(titles.join('\\n')+'\\n\\n'+tags.join(' '))};
$('export').onclick=()=>{const blob=new Blob([JSON.stringify(getSaved(),null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='thanator-ai-biblioteca.json';a.click();URL.revokeObjectURL(a.href)};
if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
